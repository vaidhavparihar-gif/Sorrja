SHREE AAVANTIKA MASALE - ANDROID APP PROJECT

यह Android WebView ऐप प्रोजेक्ट है। फीचर:
- पहली बार ऐप खोलने पर पासवर्ड सेट करना और बाद में लॉगिन
- प्रोडक्ट जोड़ना, एडिट करना और डिलीट करना
- प्रोडक्ट फोटो चुनना
- कीमत (₹) और Quantity/स्टॉक दर्ज करना
- प्रोडक्ट खोज और कुल प्रोडक्ट/स्टॉक सारांश
- जानकारी इसी फोन के ऐप में लोकल सेव होती है

महत्वपूर्ण सीमाएँ:
- यह ZIP source project है, तैयार APK नहीं।
- लॉगिन पासवर्ड इस डेमो ऐप में डिवाइस के लोकल स्टोरेज में रखा जाता है; यह सर्वर-आधारित या उच्च-सुरक्षा लॉगिन नहीं है।
- डेटा क्लाउड में सिंक नहीं होता। ऐप uninstall या app data clear करने पर डेटा मिट सकता है।
- इसे एक फोन पर निजी स्टॉक रिकॉर्ड रखने के लिए इस्तेमाल करें; संवेदनशील/व्यावसायिक डेटा के लिए नियमित बैकअप रखें।

मोबाइल से APK बनाने का तरीका:
1. GitHub अकाउंट बनाकर नया Private repository बनाएँ।
2. इस ZIP फाइल को repository के root में upload करके Commit करें।
3. अलग दी गई build-apk.yml फाइल को repository में .github/workflows/build-apk.yml नाम से Create new file करके उसका पूरा content paste करें और Commit करें।
4. GitHub repository में Actions खोलें। “Build Shree Aavantika Masale APK” चुनें और Run workflow दबाएँ।
5. Build सफल होने पर workflow run के नीचे Artifacts में Shree-Aavantika-Masale-APK डाउनलोड करें। ZIP खोलकर app-debug.apk निकालें और फोन में इंस्टॉल करें।

Build workflow इस ZIP को root से extract करता है। ZIP का नाम ठीक यह होना चाहिए:
Shree_Aavantika_Masale_Android_Project.zip
